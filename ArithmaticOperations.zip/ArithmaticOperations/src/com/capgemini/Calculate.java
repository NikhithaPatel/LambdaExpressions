package com.capgemini;

public interface Calculate {
 public int operation(int a,int b);
}
