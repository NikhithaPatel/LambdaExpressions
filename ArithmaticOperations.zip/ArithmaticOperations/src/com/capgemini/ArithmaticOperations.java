package com.capgemini;

import java.util.Scanner;

public class ArithmaticOperations {
	static Scanner sc=new Scanner(System.in);
	static int a=sc.nextInt();
    static int b=sc.nextInt();
		public static void main(String[] args) {
			Calculate add=(a , b )->{return a+b;};
			System.out.println(add.operation(a, b));
		
			Calculate sub=(a , b )->{return a-b;};
			System.out.println(sub.operation(a, b));
		
			Calculate mul=(a , b )->{return a*b;};
			System.out.println(mul.operation(a, b));
		
			Calculate div=(a , b )->{return a%b;};
			System.out.println(div.operation(a, b));
	}

	
}
