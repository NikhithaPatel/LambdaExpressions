package com.capgemini.order;

import java.util.ArrayList;

import com.capgemini.model.Order;

public class MainClass {
		
	public static void main(String[] args) {
		
		Order object=new Order(null, 0, null);
		
		 ArrayList <Order> list=new ArrayList();
		 list.add(new Order("Myntra", 10000,"accepted"));
		 list.add(new Order("FlipKart", 20000,"completed"));
		 list.add(new Order("Amazon", 30000,"dispatched"));
		 list.add(new Order("snapdeal",5000,"accepted"));
		 list.add(new Order("SheIn", 23000,"completed"));
		
		    
		 IOrders order=(name,price,status)->{for(Order n:list) {
			 if(n.getOrderPrice()>10000 || (n.getOrderStatus()).equalsIgnoreCase("accepted") || (n.getOrderStatus()).equalsIgnoreCase("completed"))
			 System.out.println(n.getOrderName());
		 };	
	
	};
}

}
