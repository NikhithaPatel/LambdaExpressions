package com.capgemini.order;

public interface IOrders {
 public void showOrders(String name,int price,String status);
}
